package vn.edu.hust.studentman.ui

import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import vn.edu.hust.studentman.R
import vn.edu.hust.studentman.adapter.StudentAdapter
import vn.edu.hust.studentman.model.StudentModel

class StudentListFragment : Fragment() {

    private lateinit var studentAdapter: StudentAdapter
    private val students = mutableListOf(
        StudentModel("Nguyễn Văn An", "SV001"),
        StudentModel("Trần Thị Bảo", "SV002"),
        StudentModel("Lê Hoàng Cường", "SV003")
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_student_list, container, false)

        // Initialize ListView and Adapter
        val listView: ListView = view.findViewById(R.id.list_view_students)
        studentAdapter = StudentAdapter(requireContext(), students)
        listView.adapter = studentAdapter

        // Register ContextMenu
        registerForContextMenu(listView)

        // Handle item clicks (optional for navigation)
        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedStudent = students[position]
            // Handle click, e.g., navigate to edit student
        }

        return view
    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        requireActivity().menuInflater.inflate(R.menu.context_menu_student, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        return when (item.itemId) {
            R.id.context_menu_edit -> {
                val action = StudentListFragmentDirections.actionStudentListFragmentToAddEditStudentFragment()
                findNavController().navigate(action)
                true
            }
            R.id.context_menu_remove -> {
                students.removeAt(info.position)
                studentAdapter.notifyDataSetChanged()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }
}
