package vn.edu.hust.studentman.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import vn.edu.hust.studentman.model.StudentModel

class StudentAdapter(private val context: Context, private val students: MutableList<StudentModel>) : BaseAdapter() {
  override fun getCount(): Int = students.size
  override fun getItem(position: Int): StudentModel = students[position]
  override fun getItemId(position: Int): Long = position.toLong()

  override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
    val view = convertView ?: LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_2, parent, false)
    val student = getItem(position)
    view.findViewById<TextView>(android.R.id.text1).text = student.name
    view.findViewById<TextView>(android.R.id.text2).text = student.id
    return view
  }
}
