package vn.edu.hust.studentman.model

data class StudentModel(var name: String, var id: String)
