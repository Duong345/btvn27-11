package vn.edu.hust.studentman.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import vn.edu.hust.studentman.R

class AddEditStudentFragment : Fragment() {

    private lateinit var editTextName: EditText
    private lateinit var editTextId: EditText

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_add_edit_student, container, false)

        // Initialize Views
        editTextName = view.findViewById(R.id.edit_text_name)
        editTextId = view.findViewById(R.id.edit_text_id)
        val btnSave: Button = view.findViewById(R.id.btn_save)

        // Handle Save Button Click
        btnSave.setOnClickListener {
            val name = editTextName.text.toString()
            val id = editTextId.text.toString()
            if (name.isNotEmpty() && id.isNotEmpty()) {
                // Save data (pass back to ListFragment or ViewModel)
                findNavController().navigateUp() // Go back to the list
            }
        }

        return view
    }
}
